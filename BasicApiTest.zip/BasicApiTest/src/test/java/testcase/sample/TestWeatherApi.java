package testcase.sample;

import biz.GetWeather;
import org.json.JSONObject;
import org.testng.annotations.Test;
public class TestWeatherApi {

    @Test
    public void testGetWeatherApi(){
        GetWeather businessApi = new GetWeather();
        String key = "75138a5425e22d09dbc882b42b5d5588";
        String location = "manila";
        JSONObject response =businessApi.testGetWeatherApi("https://samples.openweathermap.org/data/2.5/weather?q=" + location + "&appid=" + key);
        System.out.println(response.toString());
    }
}
